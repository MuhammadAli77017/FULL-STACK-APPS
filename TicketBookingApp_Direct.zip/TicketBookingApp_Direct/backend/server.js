const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const eventsDB = [
    { id: 1, type: 'Movie', title: "Dune: Part Two", releaseDate: "2024-03-01", poster: "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2JGjjc91p.jpg" },
    { id: 2, type: 'Event', title: "Tech Innovation Summit", releaseDate: "2026-05-15", poster: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=500&q=80" },
    { id: 3, type: 'Movie', title: "Oppenheimer", releaseDate: "2023-07-21", poster: "https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg" }
];

app.get('/api/events', (req, res) => {
    res.status(200).json(eventsDB);
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
