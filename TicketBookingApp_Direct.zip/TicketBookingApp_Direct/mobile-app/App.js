import React from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './src/screens/HomeScreen';

const Stack = createNativeStackNavigator();
const TicketTheme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: '#09090B', card: '#18181B', text: '#FAFAFA', border: '#27272A', primary: '#EAB308' } };

export default function App() {
  return (
    <NavigationContainer theme={TicketTheme}>
      <Stack.Navigator screenOptions={{ headerTintColor: '#EAB308', headerStyle: { backgroundColor: '#18181B' } }}>
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Events & Movies' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
