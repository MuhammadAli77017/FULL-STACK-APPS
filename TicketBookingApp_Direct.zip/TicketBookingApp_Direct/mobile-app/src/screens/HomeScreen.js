import React, { useState, useEffect } from 'react';
import { View, FlatList, TextInput, ActivityIndicator, StyleSheet, Text } from 'react-native';
import EventCard from '../components/EventCard';

export default function HomeScreen() {
  const [events, setEvents] = useState([]);
  const [filteredEvents, setFilteredEvents] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://10.0.2.2:3000/api/events')
      .then(res => res.json())
      .then(data => { setEvents(data); setFilteredEvents(data); setLoading(false); })
      .catch(err => { console.error(err); setLoading(false); });
  }, []);

  useEffect(() => {
    setFilteredEvents(searchQuery.trim() === '' ? events : events.filter(e => e.title.toLowerCase().includes(searchQuery.toLowerCase())));
  }, [searchQuery, events]);

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#EAB308" /></View>;

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <TextInput style={styles.searchInput} placeholder="Search..." placeholderTextColor="#A1A1AA" value={searchQuery} onChangeText={setSearchQuery} />
      </View>
      <FlatList data={filteredEvents} keyExtractor={item => item.id.toString()} renderItem={({ item }) => <EventCard event={item} />} />
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#09090B' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  searchContainer: { padding: 16, backgroundColor: '#18181B', borderBottomWidth: 1, borderBottomColor: '#27272A' },
  searchInput: { backgroundColor: '#27272A', color: '#FAFAFA', paddingHorizontal: 16, paddingVertical: 12, borderRadius: 8, fontSize: 16 }
});
