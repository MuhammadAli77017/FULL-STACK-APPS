import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function EventCard({ event }) {
  return (
    <TouchableOpacity style={styles.card} activeOpacity={0.8}>
      <Image source={{ uri: event.poster }} style={styles.poster} resizeMode="cover" />
      <View style={styles.infoContainer}>
        <View style={styles.tag}><Text style={styles.tagText}>{event.type}</Text></View>
        <Text style={styles.title} numberOfLines={1}>{event.title}</Text>
        <Text style={styles.date}>Release: {event.releaseDate}</Text>
      </View>
    </TouchableOpacity>
  );
}
const styles = StyleSheet.create({
  card: { flexDirection: 'row', backgroundColor: '#18181B', marginVertical: 8, marginHorizontal: 16, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: '#27272A' },
  poster: { width: 100, height: 140 },
  infoContainer: { flex: 1, padding: 12, justifyContent: 'center' },
  tag: { alignSelf: 'flex-start', backgroundColor: 'rgba(234, 179, 8, 0.15)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, marginBottom: 8 },
  tagText: { color: '#EAB308', fontSize: 12, fontWeight: 'bold' },
  title: { fontSize: 18, fontWeight: 'bold', color: '#FAFAFA', marginBottom: 4 },
  date: { fontSize: 14, color: '#A1A1AA' },
});
