import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import axios from 'axios';

const HomeScreen = () => {
    const [restaurants, setRestaurants] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [activeFilter, setActiveFilter] = useState('All');

    const cuisines = ['All', 'Italian', 'Chinese', 'Desi', 'Fast Food'];

    useEffect(() => {
        fetchRestaurants();
    }, []);

    const fetchRestaurants = async () => {
        try {
            // Replace YOUR_IP_ADDRESS with your machine's local IP (e.g., 192.168.1.5)
            const res = await axios.get('http://YOUR_IP_ADDRESS:5000/api/restaurants');
            setRestaurants(res.data);
            setFilteredData(res.data);
        } catch (error) {
            console.error("API Error:", error);
        }
    };

    const handleFilter = (cuisine) => {
        setActiveFilter(cuisine);
        if (cuisine === 'All') {
            setFilteredData(restaurants);
        } else {
            const filtered = restaurants.filter(item => item.cuisine === cuisine);
            setFilteredData(filtered);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.content}>
                <Text style={styles.header}>Explore Food</Text>

                <View style={styles.filterContainer}>
                    {cuisines.map(c => (
                        <TouchableOpacity 
                            key={c} 
                            onPress={() => handleFilter(c)}
                            style={[styles.chip, activeFilter === c && styles.activeChip]}
                        >
                            <Text style={[styles.chipText, activeFilter === c && styles.activeChipText]}>{c}</Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <FlatList
                    data={filteredData}
                    keyExtractor={(item) => item.id.toString()}
                    showsVerticalScrollIndicator={false}
                    renderItem={({ item }) => (
                        <View style={styles.card}>
                            <View>
                                <Text style={styles.name}>{item.name}</Text>
                                <Text style={styles.cuisine}>{item.cuisine}</Text>
                            </View>
                            <View style={styles.ratingBadge}>
                                <Text style={styles.ratingText}>★ {item.rating}</Text>
                            </View>
                        </View>
                    )}
                />
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#0f172a' },
    content: { flex: 1, paddingHorizontal: 20, paddingTop: 20 },
    header: { fontSize: 28, fontWeight: '800', color: '#fff', marginBottom: 20, letterSpacing: 0.5 },
    filterContainer: { flexDirection: 'row', marginBottom: 25, flexWrap: 'wrap' },
    chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 25, backgroundColor: '#1e293b', marginRight: 10, marginBottom: 10, borderWidth: 1, borderColor: '#334155' },
    activeChip: { backgroundColor: '#10b981', borderColor: '#10b981' }, 
    chipText: { color: '#94a3b8', fontSize: 14, fontWeight: '500' },
    activeChipText: { color: '#fff' },
    card: { 
        backgroundColor: 'rgba(30, 41, 59, 0.7)', 
        padding: 20, 
        borderRadius: 20, 
        marginBottom: 16, 
        flexDirection: 'row', 
        justifyContent: 'space-between',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.08)' 
    },
    name: { color: '#f8fafc', fontSize: 18, fontWeight: '700' },
    cuisine: { color: '#64748b', fontSize: 14, marginTop: 4 },
    ratingBadge: { backgroundColor: 'rgba(16, 185, 129, 0.1)', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(16, 185, 129, 0.2)' },
    ratingText: { color: '#10b981', fontWeight: 'bold', fontSize: 14 }
});

export default HomeScreen;
