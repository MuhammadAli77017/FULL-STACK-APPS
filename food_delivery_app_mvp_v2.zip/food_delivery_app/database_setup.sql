CREATE DATABASE food_db;
USE food_db;

CREATE TABLE restaurants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    cuisine VARCHAR(100),
    rating DECIMAL(2,1)
);

INSERT INTO restaurants (name, cuisine, rating) VALUES 
('Pasta Bella', 'Italian', 4.5),
('Dragon Wok', 'Chinese', 4.2),
('Desi Dhaba', 'Desi', 4.8),
('Burger Hub', 'Fast Food', 4.0),
('Spicy Tandoor', 'Desi', 4.6),
('Pizza Palace', 'Italian', 4.3);
