const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Mock Local Database
const postsDB = [
    { id: 1, userId: 101, title: "Just launched my new App! 🚀", body: "Super excited to share my latest React Native project featuring a modern SaaS UI." },
    { id: 2, userId: 102, title: "Dark Theme vs Light Theme", body: "Emerald green on a dark background is definitely the superior aesthetic for dashboards. What do you think?" },
    { id: 3, userId: 103, title: "100 Days of Code", body: "Day 45: Built an Express API today and connected it to a local MySQL database." }
];

// Fetch all posts
app.get('/api/posts', (req, res) => {
    res.status(200).json(postsDB);
});

// Fetch single post
app.get('/api/posts/:id', (req, res) => {
    const post = postsDB.find(p => p.id === parseInt(req.params.id));
    if (!post) return res.status(404).json({ message: "Post not found" });
    res.status(200).json(post);
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
