import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function DetailsScreen({ route }) {
  const { post } = route.params;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.metaContainer}>
        <Text style={styles.userId}>Posted by User #{post.userId}</Text>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>New</Text>
        </View>
      </View>
      
      <Text style={styles.title}>{post.title}</Text>
      
      <View style={styles.divider} />
      
      <Text style={styles.body}>{post.body}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  metaContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  userId: {
    fontSize: 16,
    color: '#10B981', // Emerald
    fontWeight: '600',
  },
  badge: {
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  badgeText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#F8FAFC',
    marginBottom: 15,
  },
  divider: {
    height: 1,
    backgroundColor: '#334155',
    marginBottom: 20,
  },
  body: {
    fontSize: 16,
    color: '#CBD5E1',
    lineHeight: 26,
  },
});
