import React from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import FeedScreen from './src/screens/FeedScreen';
import DetailsScreen from './src/screens/DetailsScreen';

const Stack = createNativeStackNavigator();

// Custom SaaS Dark Theme setup
const MyTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: '#0F172A', // Deep slate dark
    card: '#1E293B',
    text: '#F8FAFC',
    border: '#334155',
    primary: '#10B981', // Emerald green
  },
};

export default function App() {
  return (
    <NavigationContainer theme={MyTheme}>
      <Stack.Navigator screenOptions={{ headerTintColor: '#10B981' }}>
        <Stack.Screen name="Feed" component={FeedScreen} options={{ title: 'Social Feed' }} />
        <Stack.Screen name="Details" component={DetailsScreen} options={{ title: 'Post Details' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
