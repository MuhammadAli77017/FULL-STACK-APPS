import * as SQLite from 'expo-sqlite';

const db = SQLite.openDatabase('ecommerce.db');

export interface Product {
  id: number;
  name: string;
  price: number;
  imageUrl: string;
}

export const initDatabase = () => {
  db.transaction(tx => {
    tx.executeSql(
      'CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price REAL, imageUrl TEXT);'
    );
    
    // Seed initial data if empty
    tx.executeSql('SELECT COUNT(*) as count FROM products', [], (_, { rows }) => {
      if (rows.item(0).count === 0) {
        const initialProducts = [
          ['Premium Watch', 250, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500'],
          ['SaaS Dashboard Kit', 99, 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500'],
          ['Wireless Headphones', 150, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500']
        ];
        initialProducts.forEach(p => {
          tx.executeSql('INSERT INTO products (name, price, imageUrl) VALUES (?, ?, ?)', p);
        });
      }
    });
  });
};

export const fetchProducts = (): Promise<Product[]> => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM products',
        [],
        (_, { rows }) => resolve(rows._array),
        (_, error) => { reject(error); return false; }
      );
    });
  });
};
