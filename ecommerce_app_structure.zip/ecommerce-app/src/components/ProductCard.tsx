import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import { ShoppingCart } from 'lucide-react-native';

interface ProductProps {
  name: string;
  price: number;
  imageUrl: string;
}

const ProductCard = ({ name, price, imageUrl }: ProductProps) => {
  return (
    <View style={styles.container}>
      <BlurView intensity={20} tint="dark" style={styles.glassCard}>
        <Image source={{ uri: imageUrl }} style={styles.image} />
        <View style={styles.content}>
          <Text style={styles.title}>{name}</Text>
          <View style={styles.footer}>
            <Text style={styles.price}>${price}</Text>
            <View style={styles.iconBadge}>
              <ShoppingCart size={18} color="#10b981" />
            </View>
          </View>
        </View>
      </BlurView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  glassCard: {
    padding: 12,
  },
  image: {
    width: '100%',
    height: 180,
    borderRadius: 15,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
  },
  content: {
    marginTop: 12,
  },
  title: {
    color: '#f8fafc',
    fontSize: 18,
    fontWeight: 'bold',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  price: {
    color: '#10b981',
    fontSize: 16,
    fontWeight: '700',
  },
  iconBadge: {
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    padding: 8,
    borderRadius: 10,
  }
});

export default ProductCard;
